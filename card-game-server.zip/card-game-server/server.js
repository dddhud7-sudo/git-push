const express = require('express');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production-card-game-secret';
const IS_PROD = process.env.NODE_ENV === 'production';

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

function signToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const bearer = header.startsWith('Bearer ') ? header.slice(7) : null;
  const token = bearer || req.cookies.token;
  if (!token) return res.status(401).json({ error: 'unauthorized' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'invalid_token' });
  }
}

function publicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    displayName: row.display_name || row.username,
    bio: row.bio || '',
    avatarColor: row.avatar_color || '#c8c8a0'
  };
}

// --- Auth ---
app.post('/api/register', (req, res) => {
  try {
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const displayName = String(req.body.displayName || username).trim() || username;

    if (username.length < 2 || password.length < 2) {
      return res.status(400).json({ error: 'username_password_too_short' });
    }
    if (!/^[a-z0-9_]{2,24}$/.test(username)) {
      return res.status(400).json({ error: 'invalid_username' });
    }

    const hash = bcrypt.hashSync(password, 10);
    const info = db.prepare(
      'INSERT INTO users (username, password_hash, display_name) VALUES (?, ?, ?)'
    ).run(username, hash, displayName);

    db.prepare('INSERT INTO user_meta (user_id, meta_json) VALUES (?, ?)').run(info.lastInsertRowid, '{}');

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
    const token = signToken(user);
    res.cookie('token', token, {
      httpOnly: true,
      sameSite: IS_PROD ? 'none' : 'lax',
      secure: IS_PROD,
      maxAge: 30 * 24 * 60 * 60 * 1000
    });
    res.json({ ok: true, token, user: publicUser(user) });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'username_taken' });
    }
    console.error(e);
    res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/login', (req, res) => {
  try {
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: 'login_fail' });
    }
    const token = signToken(user);
    res.cookie('token', token, {
      httpOnly: true,
      sameSite: IS_PROD ? 'none' : 'lax',
      secure: IS_PROD,
      maxAge: 30 * 24 * 60 * 60 * 1000
    });
    res.json({ ok: true, token, user: publicUser(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

app.get('/api/me', authMiddleware, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(401).json({ error: 'unauthorized' });
  res.json({ ok: true, user: publicUser(user) });
});

app.put('/api/profile', authMiddleware, (req, res) => {
  try {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    if (!user) return res.status(401).json({ error: 'unauthorized' });
    const displayName = String(req.body.displayName ?? user.display_name ?? user.username).trim() || user.username;
    const bio = String(req.body.bio ?? user.bio ?? '').slice(0, 300);
    const avatarColor = String(req.body.avatarColor ?? user.avatar_color ?? '#c8c8a0');
    db.prepare(
      'UPDATE users SET display_name = ?, bio = ?, avatar_color = ? WHERE id = ?'
    ).run(displayName, bio, avatarColor, user.id);
    const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
    res.json({ ok: true, user: publicUser(updated) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'server_error' });
  }
});

// Optional: sync game meta (achievements etc.) per account
app.get('/api/meta', authMiddleware, (req, res) => {
  const row = db.prepare('SELECT meta_json FROM user_meta WHERE user_id = ?').get(req.user.id);
  let meta = {};
  try { meta = JSON.parse(row?.meta_json || '{}'); } catch {}
  res.json({ ok: true, meta });
});

app.put('/api/meta', authMiddleware, (req, res) => {
  try {
    const meta = req.body.meta;
    if (!meta || typeof meta !== 'object') {
      return res.status(400).json({ error: 'invalid_meta' });
    }
    const json = JSON.stringify(meta);
    db.prepare(
      `INSERT INTO user_meta (user_id, meta_json, updated_at) VALUES (?, ?, datetime('now'))
       ON CONFLICT(user_id) DO UPDATE SET meta_json = excluded.meta_json, updated_at = datetime('now')`
    ).run(req.user.id, json);
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'server_error' });
  }
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log('CARD GAME server on http://localhost:' + PORT);
});
