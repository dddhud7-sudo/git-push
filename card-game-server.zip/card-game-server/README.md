# CARD GAME (서버 로그인)

Node.js + Express + SQLite 서버가 계정을 저장합니다.  
로그인하면 **다른 기기/브라우저**에서도 같은 계정으로 접속할 수 있습니다.

## 구성

```
card-game-server/
  server.js       # API + 정적 파일 서버
  db.js           # SQLite
  package.json
  public/
    index.html    # 게임 클라이언트
  data/           # DB 파일 (자동 생성, git 제외)
```

## API

| 메서드 | 경로 | 설명 |
|--------|------|------|
| POST | `/api/register` | 회원가입 `{username, password, displayName?}` |
| POST | `/api/login` | 로그인 |
| POST | `/api/logout` | 로그아웃 |
| GET | `/api/me` | 현재 로그인 사용자 |
| PUT | `/api/profile` | 프로필 수정 |
| GET/PUT | `/api/meta` | 업적·설정 등 메타 동기화 |

토큰은 `Authorization: Bearer ...` 또는 쿠키 `token`으로 전달됩니다 (30일).

## 로컬에서 실행

```bash
cd card-game-server
npm install
npm start
```

브라우저에서 http://localhost:3000 접속

## GitHub에 올리기

1. GitHub에서 **New repository** 생성 (예: `card-game-server`)
2. 터미널에서:

```bash
cd card-game-server
git init
git add .
git commit -m "Initial card game server"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/card-game-server.git
git push -u origin main
```

`YOUR_USERNAME`을 본인 GitHub 아이디로 바꾸세요.

## 무료 서버에 배포 (Render 예시)

1. [https://render.com](https://render.com) 가입 (GitHub 연동)
2. **New → Web Service**
3. 방금 올린 저장소 선택
4. 설정:
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Environment**:
     - `JWT_SECRET` = 긴 랜덤 문자열 (예: 비밀번호 생성기로 만든 값)
     - `NODE_ENV` = `production`
5. Deploy 후 나오는 URL로 접속

> SQLite는 Render 무료 플랜에서 **디스크가 초기화**될 수 있습니다.  
> 계정을 오래 안전하게 쓰려면 나중에 PostgreSQL로 바꾸는 것을 권장합니다.  
> 프로토타입·친구와 테스트용으로는 SQLite로 충분합니다.

## Railway 배포 (대안)

1. [https://railway.app](https://railway.app) → GitHub 로그인
2. New Project → Deploy from GitHub repo
3. Variables에 `JWT_SECRET`, `NODE_ENV=production` 추가
4. 생성되는 공개 URL 사용

## 보안 참고

- 운영 전에 반드시 `JWT_SECRET`을 변경하세요.
- 이 프로젝트는 학습/프로토타입용입니다. 상용 서비스 수준의 보안 감사는 되어 있지 않습니다.
